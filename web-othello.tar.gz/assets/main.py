# -*- coding: utf-8 -*-
import pygame

# -----------------------------
# 定数
# -----------------------------
WIDTH = 480
HEIGHT = 480
CELL = WIDTH // 8
GREEN = (0, 128, 0)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# -----------------------------
# オセロのロジック
# -----------------------------
class Othello:
    def __init__(self):
        self.board = [[0]*8 for _ in range(8)]
        self.board[3][3] = 2
        self.board[3][4] = 1
        self.board[4][3] = 1
        self.board[4][4] = 2
        self.turn = 1  # 1=黒, 2=白

    def inside(self, x, y):
        return 0 <= x < 8 and 0 <= y < 8

    def valid_moves(self, color):
        moves = []
        for y in range(8):
            for x in range(8):
                if self.board[y][x] != 0:
                    continue
                if self.can_flip(x, y, color):
                    moves.append((x, y))
        return moves

    def can_flip(self, x, y, color):
        opp = 3 - color
        dirs = [(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]
        for dx, dy in dirs:
            nx, ny = x + dx, y + dy
            found_opp = False
            while self.inside(nx, ny) and self.board[ny][nx] == opp:
                nx += dx
                ny += dy
                found_opp = True
            if found_opp and self.inside(nx, ny) and self.board[ny][nx] == color:
                return True
        return False

    def place(self, x, y, color):
        if not self.can_flip(x, y, color):
            return False
        self.board[y][x] = color
        self.flip(x, y, color)
        return True

    def flip(self, x, y, color):
        opp = 3 - color
        dirs = [(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]
        for dx, dy in dirs:
            nx, ny = x + dx, y + dy
            stones = []
            while self.inside(nx, ny) and self.board[ny][nx] == opp:
                stones.append((nx, ny))
                nx += dx
                ny += dy
            if stones and self.inside(nx, ny) and self.board[ny][nx] == color:
                for sx, sy in stones:
                    self.board[sy][sx] = color

    def ai_move(self):
        moves = self.valid_moves(2)
        if not moves:
            return
        # 一番多くひっくり返せる手を選ぶ
        best = None
        best_score = -1
        for x, y in moves:
            score = self.count_flips(x, y, 2)
            if score > best_score:
                best_score = score
                best = (x, y)
        if best:
            self.place(best[0], best[1], 2)

    def count_flips(self, x, y, color):
        opp = 3 - color
        dirs = [(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]
        total = 0
        for dx, dy in dirs:
            nx, ny = x + dx, y + dy
            cnt = 0
            while self.inside(nx, ny) and self.board[ny][nx] == opp:
                cnt += 1
                nx += dx
                ny += dy
            if cnt and self.inside(nx, ny) and self.board[ny][nx] == color:
                total += cnt
        return total


# -----------------------------
# 描画
# -----------------------------
def draw(screen, game):
    screen.fill(GREEN)
    # グリッド
    for i in range(9):
        pygame.draw.line(screen, BLACK, (i*CELL, 0), (i*CELL, HEIGHT), 2)
        pygame.draw.line(screen, BLACK, (0, i*CELL), (WIDTH, i*CELL), 2)

    # 石
    for y in range(8):
        for x in range(8):
            if game.board[y][x] == 1:
                pygame.draw.circle(screen, BLACK, (x*CELL+CELL//2, y*CELL+CELL//2), CELL//2-4)
            elif game.board[y][x] == 2:
                pygame.draw.circle(screen, WHITE, (x*CELL+CELL//2, y*CELL+CELL//2), CELL//2-4)


# -----------------------------
# メインループ（pygbag 対応）
# -----------------------------
def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    clock = pygame.time.Clock()

    game = Othello()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False  # sys.exit() は使わない

            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()
                x = mx // CELL
                y = my // CELL
                if game.place(x, y, 1):
                    game.ai_move()

        draw(screen, game)
        pygame.display.flip()
        clock.tick(30)


if __name__ == "__main__":
    main()