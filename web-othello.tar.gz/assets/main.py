import pygame
import asyncio

WIDTH = 480
HEIGHT = 520
BOARD_TOP = 40
CELL = WIDTH // 8
GREEN = (0, 128, 0)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

class Othello:
    def __init__(self):
        self.board = [[0]*8 for _ in range(8)]
        self.board[3][3] = 2
        self.board[3][4] = 1
        self.board[4][3] = 1
        self.board[4][4] = 2
        self.turn = 1

    def inside(self, x, y):
        return 0 <= x < 8 and 0 <= y < 8

    def valid_moves(self, color):
        moves = []
        for y in range(8):
            for x in range(8):
                if self.board[y][x] != 0:
                    continue
                if self.can_flip(x, y, color):
                    moves.append((x, y))
        return moves

    def can_flip(self, x, y, color):
        opp = 3 - color
        dirs = [(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]
        for dx, dy in dirs:
            nx, ny = x + dx, y + dy
            found_opp = False
            while self.inside(nx, ny) and self.board[ny][nx] == opp:
                nx += dx
                ny += dy
                found_opp = True
            if found_opp and self.inside(nx, ny) and self.board[ny][nx] == color:
                return True
        return False

    def place(self, x, y, color):
        if not self.can_flip(x, y, color):
            return False
        self.board[y][x] = color
        self.flip(x, y, color)
        return True

    def flip(self, x, y, color):
        opp = 3 - color
        dirs = [(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(1,-1),(-1,-1)]
        for dx, dy in dirs:
            nx, ny = x + dx, y + dy
            stones = []
            while self.inside(nx, ny) and self.board[ny][nx] == opp:
                stones.append((nx, ny))
                nx += dx
                ny += dy
            if stones and self.inside(nx, ny) and self.board[ny][nx] == color:
                for sx, sy in stones:
                    self.board[sy][sx] = color

    def ai_move(self):
        moves = self.valid_moves(2)
        if not moves:
            return
        best = None
        best_score = -1
        for x, y in moves:
            score = self.count_flips(x, y, 2)
            if score > best_score:
                best_score = score
                best = (x, y)
        if best:
            self.place(best[0], best[1], 2)

    def count_flips(self, x, y, color):
        opp = 3 - color
        dirs = [(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]
        total = 0
        for dx, dy in dirs:
            nx, ny = x + dx, y + dy
            cnt = 0
            while self.inside(nx, ny) and self.board[ny][nx] == opp:
                cnt += 1
                nx += dx
                ny += dy
            if cnt and self.inside(nx, ny) and self.board[ny][nx] == color:
                total += cnt
        return total

    def count_stones(self):
        black = sum(row.count(1) for row in self.board)
        white = sum(row.count(2) for row in self.board)
        return black, white

def draw(screen, game):
    screen.fill(GREEN)

    # --- スコア表示（盤面の外） ---
    font = pygame.font.Font('assets/fonts/NotoSansJP-Regular.ttf', 24)
    black_count, white_count = game.count_stones()
    text = font.render(f"黒: {black_count}   白: {white_count}", True, (255, 255, 255))
    screen.blit(text, (10, 5))

    # --- グリッド ---
    for i in range(9):
        pygame.draw.line(screen, BLACK, (i*CELL, BOARD_TOP), (i*CELL, BOARD_TOP + 480), 2)
        pygame.draw.line(screen, BLACK, (0, BOARD_TOP + i*CELL), (WIDTH, BOARD_TOP + i*CELL), 2)

    # --- 石（縁取り付き）---
    for y in range(8):
        for x in range(8):
            cx = x*CELL + CELL//2
            cy = BOARD_TOP + y*CELL + CELL//2
            r = CELL//2 - 4

            if game.board[y][x] == 1:
                pygame.draw.circle(screen, (50, 50, 50), (cx, cy), r + 2)
                pygame.draw.circle(screen, BLACK, (cx, cy), r)
            elif game.board[y][x] == 2:
                pygame.draw.circle(screen, BLACK, (cx, cy), r + 2)
                pygame.draw.circle(screen, WHITE, (cx, cy), r)

    # --- 合法手ハイライト ---
    hint = pygame.Surface((CELL, CELL), pygame.SRCALPHA)
    pygame.draw.circle(hint, (255, 255, 255, 80), (CELL//2, CELL//2), CELL//2 - 6)

    moves = game.valid_moves(1)
    for x, y in moves:
        screen.blit(hint, (x*CELL, BOARD_TOP + y*CELL))

async def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    clock = pygame.time.Clock()
    game = Othello()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mx, my = pygame.mouse.get_pos()
                if my < BOARD_TOP:
                    continue
                x = mx // CELL
                y = (my - BOARD_TOP) // CELL

                # ★ ここが重要：空きマス以外は無視
                if game.board[y][x] != 0:
                    continue

                # 合法手以外はクリックしても無視する
                moves = game.valid_moves(1)
                if (x, y) not in moves:
                    continue

                # ★ 空きマスなら置く
                if game.place(x, y, 1):
                    game.ai_move()

            # --- ゲーム終了判定 ---
            if not game.valid_moves(1) and not game.valid_moves(2):
                black, white = game.count_stones()

                if black > white:
                    result = "黒の勝ち！"
                elif white > black:
                    result = "白の勝ち！"
                else:
                    result = "引き分け"

                font = pygame.font.Font('assets/fonts/NotoSansJP-Regular.ttf', 48)
                text = font.render(result, True, (255, 255, 0))
                screen.blit(text, (120, HEIGHT//2 - 20))
                pygame.display.flip()

                await asyncio.sleep(3)
                return
        draw(screen, game)
        pygame.display.flip()
        clock.tick(30)

        await asyncio.sleep(0)  # ← これがフリーズ防止の最重要ポイント


if __name__ == "__main__":
    asyncio.run(main())